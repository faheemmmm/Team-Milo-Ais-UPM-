"""Kick aiming: choose where to send the ball.

Pure functions over Context. Coordinates are team-relative (+x toward the
opponent goal). Nothing here ever aims backward past ``AIM_MAX_OFFSET_RAD``
from the goal direction, so it cannot produce a kick toward our own goal.
"""

from __future__ import annotations

import math

from ..framework.types import Context
from ..param import (
    AIM_MAX_OFFSET_RAD,
    AIM_OPP_CLEAR_M,
    AIM_RAY_LEN_M,
    AIM_SAMPLES,
    AIM_STEP_RAD,
    GOAL_POST_MARGIN_M,
    SHOOT_RANGE_M,
    SIDELINE_MARGIN_M,
)
from .geom import angle_to, clamp, dist, normalize_angle


def _opp_positions(ctx: Context) -> list[tuple[float, float]]:
    return [
        (r.pose.x, r.pose.y) for r in ctx.opponents.values() if r.pose is not None
    ]


def _seg_clearance(
    ax: float, ay: float, bx: float, by: float, px: float, py: float,
) -> float:
    """Distance from point P to segment AB."""
    vx, vy = bx - ax, by - ay
    l2 = vx * vx + vy * vy
    if l2 < 1e-9:
        return math.hypot(px - ax, py - ay)
    t = clamp(((px - ax) * vx + (py - ay) * vy) / l2, 0.0, 1.0)
    return math.hypot(px - (ax + vx * t), py - (ay + vy * t))


def line_clearance(
    ctx: Context, ax: float, ay: float, bx: float, by: float,
) -> float:
    """Smallest opponent distance to segment AB, capped at AIM_OPP_CLEAR_M."""
    best = AIM_OPP_CLEAR_M
    for ox, oy in _opp_positions(ctx):
        best = min(best, _seg_clearance(ax, ay, bx, by, ox, oy))
    return best


def in_shooting_range(ctx: Context, bx: float, by: float) -> bool:
    gx = ctx.field.length / 2.0
    return dist(bx, by, gx, 0.0) <= SHOOT_RANGE_M and bx > 0.0


def _goal_candidates(ctx: Context) -> list[float]:
    half = ctx.field.goal_width / 2.0 - GOAL_POST_MARGIN_M
    half = max(0.2, half)
    n = max(2, AIM_SAMPLES)
    return [-half + 2.0 * half * i / (n - 1) for i in range(n)]


def score_goal_target(ctx: Context, bx: float, by: float, ty: float) -> float:
    """Higher is better. Opponent clearance dominates; center is a tie-break."""
    gx = ctx.field.length / 2.0
    clear = line_clearance(ctx, bx, by, gx, ty) / AIM_OPP_CLEAR_M   # 0..1
    # Opponents near the goal mouth count extra (keeper): check clearance of the
    # final stretch too.
    end = line_clearance(ctx, gx - 1.5, by + (ty - by) * 0.85, gx, ty) / AIM_OPP_CLEAR_M
    center_bias = 1.0 - abs(ty) / max(ctx.field.goal_width / 2.0, 1e-6)
    return 1.0 * clear + 1.2 * end + 0.15 * center_bias


def best_goal_target(ctx: Context, bx: float, by: float) -> tuple[float, float, float]:
    """Return ``(target_x, target_y, score)`` for the best shot at goal."""
    gx = ctx.field.length / 2.0
    best_y, best_s = 0.0, -math.inf
    for ty in _goal_candidates(ctx):
        s = score_goal_target(ctx, bx, by, ty)
        if s > best_s:
            best_y, best_s = ty, s
    return gx, best_y, best_s


def score_direction(ctx: Context, bx: float, by: float, theta: float) -> float:
    """Score an open-field kick direction (progress + safety)."""
    gx = ctx.field.length / 2.0
    ex = bx + math.cos(theta) * AIM_RAY_LEN_M
    ey = by + math.sin(theta) * AIM_RAY_LEN_M

    toward_goal = angle_to(bx, by, gx, 0.0)
    off = abs(normalize_angle(theta - toward_goal))
    progress = math.cos(off)                               # 1 = straight at goal

    clear = line_clearance(ctx, bx, by, ex, ey) / AIM_OPP_CLEAR_M

    half_w = ctx.field.width / 2.0 - SIDELINE_MARGIN_M
    half_l = ctx.field.length / 2.0 - SIDELINE_MARGIN_M
    edge_pen = 0.0
    if abs(ey) > half_w:
        edge_pen += 1.0 + (abs(ey) - half_w)
    if abs(ex) > half_l and abs(ey) > ctx.field.goal_width / 2.0:
        edge_pen += 0.8                                    # Don't hit the end line
    # Backward kicks are never allowed by the candidate set, but a kick that
    # still travels toward our goal line is strongly discouraged.
    back_pen = 0.0 if math.cos(theta) > 0.05 else 0.6
    return 1.0 * progress + 0.9 * clear - edge_pen - back_pen


def best_direction(ctx: Context, bx: float, by: float) -> tuple[float, float]:
    """Return ``(direction, score)`` for open-field play."""
    gx = ctx.field.length / 2.0
    base = angle_to(bx, by, gx, 0.0)
    best_t, best_s = base, -math.inf
    k = 0
    offsets = [0.0]
    while k * AIM_STEP_RAD <= AIM_MAX_OFFSET_RAD + 1e-9:
        k += 1
        offsets += [k * AIM_STEP_RAD, -k * AIM_STEP_RAD]
    for off in offsets:
        t = base + off
        s = score_direction(ctx, bx, by, t)
        if s > best_s + 1e-9:
            best_t, best_s = t, s
    return best_t, best_s


def choose_aim(ctx: Context, bx: float, by: float) -> tuple[float, float, bool]:
    """Return ``(direction, score, is_shot)`` for a kick from (bx, by)."""
    if in_shooting_range(ctx, bx, by):
        tx, ty, s = best_goal_target(ctx, bx, by)
        return angle_to(bx, by, tx, ty), s, True
    theta, s = best_direction(ctx, bx, by)
    return theta, s, False
