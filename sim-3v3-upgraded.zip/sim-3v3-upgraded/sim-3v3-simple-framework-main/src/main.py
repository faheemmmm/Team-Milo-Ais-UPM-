

"""SoccerSim strategy entry point and primary match logic.

3v3 strategy:
- Striker: attacks the ball and shoots.
- Defender: protects the area between the ball and our goal.
- Midfielder: moves into an attacking support position.

The existing Booster framework, phase handling, kickoff logic, and
debug visualisation are retained.
"""

from __future__ import annotations

import logging
import math
from enum import Enum

from booster_agent_framework import AgentBase

from .framework.agent import SoccerAgentMixin
from .framework.types import KICKING_TEAM_NONE, Context, GameState, SetPlay
from .param import *
from .player import Player
from .utils import angle_to, clamp_inside_field, dist, opponent_goal, own_goal


_log = logging.getLogger(__name__)


# ======================================================================
# Phase state machine
# ======================================================================

class Phase(Enum):
    NORMAL = "normal"
    OUR_KICKOFF = "our_kickoff"
    OPP_KICKOFF = "opp_kickoff"
    OUR_SET_PLAY = "our_set_play"
    OPP_SET_PLAY = "opp_set_play"
    READY = "ready"
    STOPPED = "stopped"


def get_phase(context: Context) -> Phase:
    """Determine the current match phase."""
    g = context.game

    if g is None:
        return Phase.STOPPED

    state = g.state

    if state == GameState.READY:
        return Phase.READY

    if state == GameState.PLAYING and not g.stopped:

        if g.set_play != SetPlay.NONE and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id

            if g.kicking_team == our_team:
                return Phase.OUR_SET_PLAY
            else:
                return Phase.OPP_SET_PLAY

        if g.secondary_time > 0 and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id

            if g.kicking_team == our_team:
                return Phase.OUR_KICKOFF
            else:
                return Phase.OPP_KICKOFF

        return Phase.NORMAL

    return Phase.STOPPED


def get_set_play_type(context: Context) -> SetPlay:
    """Return the active set-play type."""
    g = context.game

    if g is None:
        return SetPlay.NONE

    return g.set_play


# ======================================================================
# Agent entry point
# ======================================================================

class SoccerSimAgent(SoccerAgentMixin, AgentBase):
    """3v3 SoccerSim agent."""

    player_class = Player

    def init_store(self, store) -> None:
        _log.info("init_store called")

        store.prev_phase = None
        store.cur_phase = None
        store.kickoff_taker = None
        store.normal_attacker = None
        store.normal_defender = None
        store.support_side = None

    @staticmethod
    def play(context: Context, players: list[Player], store) -> None:

        phase = get_phase(context)

        store.prev_phase = store.cur_phase
        store.cur_phase = phase

        _analyze_and_draw(context, players, store)

        from .framework import debugdraw

        g = context.game
        game_state = g.state.value if g is not None else "none"
        set_play = g.set_play.value if g is not None else "none"
        secondary_time = g.secondary_time if g is not None else 0.0

        debugdraw.text(
            0.0,
            context.field.width / 2.0 + 0.2,
            f"phase={phase.value} state={game_state} "
            f"set={set_play} secondary={secondary_time:.1f}",
            rgb=(1.0, 1.0, 0.0),
            ns="phase",
        )

        # Keep only players that are ready and able to act.
        active: list[Player] = []

        for p in players:
            ready = p.ensure_ready()

            if p.is_penalized:
                p.action = "penalized"
                p.stop()

            elif not ready:
                p.action = "fallen" if p.is_fallen else "switching_mode"

            elif p.pose is None:
                p.action = "no_pose"
                p.stop()

            else:
                active.append(p)

        # Dispatch the team strategy.
        if phase == Phase.NORMAL:
            _act_normal(context, active, store)

        elif phase == Phase.OUR_KICKOFF:
            _clear_normal_sticky(store)
            _act_our_kickoff(context, active, store)

        elif phase == Phase.OPP_KICKOFF:
            _clear_normal_sticky(store)
            _act_opp_kickoff(context, active)

        elif phase == Phase.OUR_SET_PLAY:
            _clear_normal_sticky(store)
            _act_our_set_play(context, active, store)

        elif phase == Phase.OPP_SET_PLAY:
            _clear_normal_sticky(store)
            _act_opp_set_play(context, active, store)

        elif phase == Phase.READY:
            _clear_normal_sticky(store)
            _act_ready(context, active)

        elif phase == Phase.STOPPED:
            _clear_normal_sticky(store)

            for p in active:
                p.action = "stopped"
                p.stop()

        # Draw all teammates, including players who cannot currently act.
        for p in players:
            _draw_teammate_marker(p)


# ======================================================================
# Player selection and distance helpers
# ======================================================================

def _clear_normal_sticky(store) -> None:
    store.normal_attacker = None
    store.normal_defender = None
    store.support_side = None


def _player_dist_to_position(
    p: Player,
    target: tuple[float, float],
) -> float:
    """Return infinity if the player's position is unknown."""

    pose = p.pose

    if pose is None:
        return math.inf

    return dist(pose.x, pose.y, *target)


def _player_dist_to_ball(context: Context, p: Player) -> float:
    """Calculate effective player-to-ball distance."""

    ball = context.ball

    return (
        _player_dist_to_position(p, (ball.x, ball.y))
        + _fallen_time_cost(p)
        if ball is not None else math.inf
    )


def _fallen_time_cost(p: Player) -> float:
    return FALLEN_COST if p.is_fallen else 0.0


def _select_closest_attacker(
    context: Context,
    players: list[Player],
    preferred_id: int | None = None,
) -> Player:
    """Select the best player to attack the ball."""

    ranked = [
        (p, _player_dist_to_ball(context, p))
        for p in players
    ]

    best, best_dist = min(
        ranked,
        key=lambda item: item[1],
    )

    preferred = next(
        (item for item in ranked if item[0].id == preferred_id),
        None,
    )

    # Avoid changing attackers unnecessarily.
    if (
        preferred is not None
        and preferred[1] <= best_dist + ATTACKER_KEEP_DIST_MARGIN_M
    ):
        return preferred[0]

    return best


def _select_defender(
    players: list[Player],
    own: tuple[float, float],
    preferred_id: int | None,
) -> Player:
    """Pick the player closest to our goal, keeping the previous choice
    unless another player is clearly closer."""

    ranked = [(p, _player_dist_to_position(p, own)) for p in players]
    best, best_dist = min(ranked, key=lambda item: item[1])

    preferred = next(
        (item for item in ranked if item[0].id == preferred_id),
        None,
    )

    if (
        preferred is not None
        and preferred[1] <= best_dist + DEFENDER_KEEP_DIST_MARGIN_M
    ):
        return preferred[0]

    return best


def _pick_support_side(ball_y: float, previous: float | None) -> float:
    """Choose the side of the ball for support, with a dead band."""

    if previous is not None and abs(ball_y) < SUPPORT_SIDE_DEADBAND_M:
        return previous

    return -1.0 if ball_y >= 0 else 1.0


# ======================================================================
# Tactical positioning helpers
# ======================================================================

def _unit_direction(start, end):
    """Calculate a unit direction from one point to another."""

    dx = end[0] - start[0]
    dy = end[1] - start[1]

    length = math.hypot(dx, dy)

    if length < 1e-6:
        return (1.0, 0.0)

    return (dx / length, dy / length)


def _get_support_position(
    context: Context,
    ball,
    own,
    opponent,
    side: float | None = None,
    slot: int = 0,
) -> tuple[float, float]:
    """Find an attacking support position away from the striker.

    ``side`` is the lateral side (+1/-1) relative to the ball and ``slot``
    spreads additional supporters so they do not stack on one point.
    """

    attack_x, attack_y = _unit_direction(own, opponent)

    # Direction perpendicular to the attacking direction.
    side_x = -attack_y
    side_y = attack_x

    forward_distance = 1.5 + 0.8 * slot
    lateral_distance = 1.8 + 0.6 * slot

    # Choose the opposite side of the ball when possible.
    if side is None:
        side = -1.0 if ball[1] >= 0 else 1.0

    target_x = (
        ball[0]
        + attack_x * forward_distance
        + side_x * lateral_distance * side
    )

    target_y = (
        ball[1]
        + attack_y * forward_distance
        + side_y * lateral_distance * side
    )

    return clamp_inside_field(context, target_x, target_y)


def _get_defensive_position(
    context: Context,
    ball,
    own,
) -> tuple[float, float]:
    """Position the defender between the ball and our own goal."""

    dx, dy = _unit_direction(own, ball)

    distance_to_ball = dist(
        own[0],
        own[1],
        ball[0],
        ball[1],
    )

    distance = min(2.0, distance_to_ball * 0.55)

    target_x = own[0] + dx * distance
    target_y = own[1] + dy * distance

    return clamp_inside_field(context, target_x, target_y)


# ======================================================================
# NORMAL PLAY: 3v3 attacking strategy
# ======================================================================

def _act_normal(
    context: Context,
    players: list[Player],
    store,
) -> None:
    """Assign striker, defender, and midfielder roles."""

    if not players:
        return

    ball_obj = context.ball

    if ball_obj is None:
        for p in players:
            p.action = "search"
            p.stop()

        return

    ball = (ball_obj.x, ball_obj.y)

    own = own_goal(context)
    opponent = opponent_goal(context)

    # --------------------------------------------------------------
    # ROLE 1: STRIKER
    # --------------------------------------------------------------

    attacker = _select_closest_attacker(
        context,
        players,
        getattr(store, "normal_attacker", None),
    )

    store.normal_attacker = attacker.id

    attacker.action = "STRIKER:ATTACK"

    # The striker approaches the ball and shoots.
    attacker.attack()

    # --------------------------------------------------------------
    # Remaining players
    # --------------------------------------------------------------

    remaining = [
        p for p in players
        if p is not attacker
    ]

    if not remaining:
        return

    # --------------------------------------------------------------
    # ROLE 2: DEFENDER
    # --------------------------------------------------------------

    defender = _select_defender(
        remaining,
        own,
        getattr(store, "normal_defender", None),
    )

    store.normal_defender = defender.id

    remaining.remove(defender)

    defender_position = _get_defensive_position(
        context,
        ball,
        own,
    )

    defender.action = "DEFENDER:COVER"

    defender.walk_to(
        defender_position,
        face=angle_to(
            defender_position[0],
            defender_position[1],
            ball[0],
            ball[1],
        ),
        avoid_ball=True,
        avoid_robots=True,
    )

    # --------------------------------------------------------------
    # ROLE 3: MIDFIELDER / SUPPORT
    # --------------------------------------------------------------

    store.support_side = _pick_support_side(
        ball[1],
        getattr(store, "support_side", None),
    )

    for slot, midfielder in enumerate(remaining):

        support_position = _get_support_position(
            context,
            ball,
            own,
            opponent,
            side=store.support_side,
            slot=slot,
        )

        midfielder.action = "MIDFIELDER:SUPPORT"

        midfielder.walk_to(
            support_position,
            face=angle_to(
                support_position[0],
                support_position[1],
                opponent[0],
                opponent[1],
            ),
            avoid_ball=True,
            avoid_robots=True,
        )


# ======================================================================
# OUR KICKOFF
# ======================================================================

def _act_our_kickoff(
    context: Context,
    players: list[Player],
    store,
) -> None:
    """Select a kickoff taker and position the other players."""

    if not players:
        return

    active_ids = {
        p.id for p in players
    }

    if (
        store.prev_phase != Phase.OUR_KICKOFF
        or store.kickoff_taker not in active_ids
    ):
        store.kickoff_taker = _select_closest_attacker(
            context,
            players,
        ).id

    attacker_id = store.kickoff_taker

    attacker = next(
        (p for p in players if p.id == attacker_id),
        None,
    )

    if attacker is None:
        return

    attacker.action = "kickoff"

    attacker.kick(
        0.1,
        KICK_POWER_OUR_KICKOFF,
    )

    rest = [
        p for p in players
        if p is not attacker
    ]

    if rest:
        gx, gy = own_goal(context)

        guard = min(
            rest,
            key=lambda p: _player_dist_to_position(p, (gx, gy)),
        )

        guard.guard()

        rest = [
            p for p in rest
            if p is not guard
        ]

    for p in rest:
        p.action = "stay"
        p.stop()


# ======================================================================
# OPPONENT KICKOFF
# ======================================================================

def _act_opp_kickoff(
    context: Context,
    players: list[Player],
) -> None:
    """Defend while the opponent takes kickoff."""

    if not players:
        return

    gx, gy = own_goal(context)

    guard = min(
        players,
        key=lambda p: _player_dist_to_position(p, (gx, gy)),
    )

    guard.guard()

    rest = [
        p for p in players
        if p is not guard
    ]

    r = context.field.circle_radius

    slots = [
        (-r - 0.5, 0.0),
        (-r - 2.0, 0.5),
    ]

    for p, target in zip(rest, slots):
        p.action = "opp_kickoff:ready"

        p.walk_to(
            target,
            avoid_ball=True,
            avoid_robots=True,
        )


# ======================================================================
# OUR SET PLAY
# ======================================================================

def _act_our_set_play(
    context: Context,
    players: list[Player],
    store,
) -> None:
    """Use normal attacking strategy during our set plays."""

    # All of our set plays currently use the normal attacking roles.
    # Branch on get_set_play_type(context) here to specialise later.
    _act_normal(context, players, store)


# ======================================================================
# OPPONENT SET PLAY
# ======================================================================

def _act_opp_set_play(
    context: Context,
    players: list[Player],
    store,
) -> None:
    """Move players outside the opponent's set-play clearance area."""

    ball = context.ball

    radius = OPP_SET_PLAY_CLEARANCE_M + ARRIVE_DIST

    half_l = (
        context.field.length / 2.0
        - OPP_SET_PLAY_FIELD_MARGIN_M
    )

    half_w = (
        context.field.width / 2.0
        - OPP_SET_PLAY_FIELD_MARGIN_M
    )

    for p in players:

        pose = p.pose

        p.action = "opp_set:wait"

        if ball is None or pose is None:
            p.stop()
            continue

        if dist(
            pose.x,
            pose.y,
            ball.x,
            ball.y,
        ) >= OPP_SET_PLAY_CLEARANCE_M:
            p.stop()
            continue

        outward = angle_to(
            ball.x,
            ball.y,
            pose.x,
            pose.y,
        )

        candidates = [
            (
                ball.x + math.cos(outward) * radius,
                ball.y + math.sin(outward) * radius,
            )
        ]

        for x in (-half_l, half_l):

            remaining = radius ** 2 - (x - ball.x) ** 2

            if remaining >= 0.0:
                offset = math.sqrt(remaining)

                candidates.extend(
                    (x, ball.y + sign * offset)
                    for sign in (-1.0, 1.0)
                )

        for y in (-half_w, half_w):

            remaining = radius ** 2 - (y - ball.y) ** 2

            if remaining >= 0.0:
                offset = math.sqrt(remaining)

                candidates.extend(
                    (ball.x + sign * offset, y)
                    for sign in (-1.0, 1.0)
                )

        candidates = [
            t for t in candidates
            if t == clamp_inside_field(
                context,
                *t,
                margin=OPP_SET_PLAY_FIELD_MARGIN_M,
            )
        ]

        if not candidates:
            p.stop()
            continue

        px, py = pose.x, pose.y

        target = min(
            candidates,
            key=lambda t: dist(px, py, *t),
        )

        length = dist(
            pose.x,
            pose.y,
            *target,
        )

        ratio = min(
            1.0,
            OMNI_DIST / (2.0 * max(length, 1e-6)),
        )

        step = (
            pose.x + (target[0] - pose.x) * ratio,
            pose.y + (target[1] - pose.y) * ratio,
        )

        p.action = "opp_set:retreat"

        p.walk_to(
            step,
            face=angle_to(
                pose.x,
                pose.y,
                ball.x,
                ball.y,
            ),
        )


# ======================================================================
# READY POSITIONS
# ======================================================================

def _act_ready(
    context: Context,
    players: list[Player],
) -> None:
    """Move players into their starting positions."""

    # Assign slots by player id so roles do not swap when a robot drops out.
    players = sorted(players, key=lambda p: p.id)

    game = context.game

    our_kickoff = (
        game is not None
        and game.kicking_team == context.team_id
    )

    field = context.field

    # Our kickoff positions.
    if our_kickoff:

        if len(players) >= 1:
            p1 = players[0]
            p1.action = "ready"

            p1.walk_to(
                (-field.circle_radius, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )

        if len(players) >= 2:
            p2 = players[1]
            p2.action = "ready"

            p2.walk_to(
                (
                    -field.length / 2.0
                    + field.goal_area_length,
                    0.0,
                ),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )

        if len(players) >= 3:
            p3 = players[2]
            p3.action = "ready"

            p3.walk_to(
                (-0.5, field.circle_radius + 2),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )

    # Opponent kickoff positions.
    else:

        if len(players) >= 1:
            p1 = players[0]
            p1.action = "ready"

            p1.walk_to(
                (-field.circle_radius - 0.5, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )

        if len(players) >= 2:
            p2 = players[1]
            p2.action = "ready"

            p2.walk_to(
                (
                    -field.length / 2.0
                    + field.goal_area_length,
                    0.0,
                ),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )

        if len(players) >= 3:
            p3 = players[2]
            p3.action = "ready"

            p3.walk_to(
                (
                    -field.length / 2.0
                    + field.penalty_area_length,
                    0.0,
                ),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )


# ======================================================================
# VISUALISATION
# ======================================================================

def _draw_teammate_marker(p: Player) -> None:
    """Draw teammates and their current actions."""

    from .framework import debugdraw

    pose = p.pose

    if pose is None:
        return

    red = (1.0, 0.2, 0.2)

    if p.is_kicking:
        debugdraw.cube(
            pose.x,
            pose.y,
            rgb=red,
            scale=0.38,
            ns="teammate",
        )

    else:
        debugdraw.point(
            pose.x,
            pose.y,
            rgb=red,
            scale=0.3,
            ns="teammate",
        )

    kick_tag = " [KICK]" if p.is_kicking else ""

    label = f"{p.id}:{p.action}{kick_tag}"

    debugdraw.text(
        pose.x,
        pose.y,
        label,
        rgb=(1.0, 0.9, 0.6),
        ns="teammate_id",
    )


def _analyze_and_draw(
    context: Context,
    players: list[Player],
    store,
) -> None:
    """Draw the ball and distances between players and the ball."""

    from .framework import debugdraw

    ball = context.ball

    if ball is None:
        return

    # Draw current ball position.
    debugdraw.point(
        ball.x,
        ball.y,
        rgb=(0.0, 1.0, 0.0),
        scale=0.2,
        ns="ball_current",
    )

    # Draw teammate distances.
    for p in players:

        pose = p.pose

        if pose is None:
            continue

        d = dist(
            pose.x,
            pose.y,
            ball.x,
            ball.y,
        )

        debugdraw.text(
            pose.x + 0.3,
            pose.y - 0.3,
            f"{d:.1f}m",
            rgb=(1.0, 0.6, 0.6),
            ns="dist_ours",
        )

    # Draw opponent distances.
    for r in context.opponents.values():

        pose = r.pose

        if pose is None:
            continue

        d = dist(
            pose.x,
            pose.y,
            ball.x,
            ball.y,
        )

        debugdraw.text(
            pose.x + 0.3,
            pose.y - 0.3,
            f"{d:.1f}m",
            rgb=(0.6, 0.6, 1.0),
            ns="dist_opp",
        )
