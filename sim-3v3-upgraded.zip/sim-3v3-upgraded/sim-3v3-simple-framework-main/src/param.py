
"""Advanced 3v3 Humanoid Soccer Strategy Parameters.

Playing style:
- Aggressive attacking
- Fast ball recovery
- Controlled shooting
- Compact defensive positioning
- Intelligent obstacle avoidance
- Stable humanoid locomotion
"""

from __future__ import annotations
import math


# ============================================================
# 1. KICK POWER
# ============================================================

KICK_POWER_MIN = 1.0
KICK_POWER_MAX = 10.0

# General attacking kick
KICK_POWER_DEFAULT = 7.0

# Strong clearance and long-distance attacking
KICK_POWER_BACKFIELD = 8.0

# Controlled kickoff
KICK_POWER_OUR_KICKOFF = 6.0


# ============================================================
# 2. MOVEMENT CONTROL
# ============================================================

# More precise arrival and smoother movement
ARRIVE_DIST = 0.12
OMNI_DIST = 0.8

# Faster directional adjustment
TURN_THRESHOLD = 0.35

# Maintain balance while allowing fast movement
MAX_LINEAR = 1.8
MAX_ANGULAR = 2.4

# Movement response
LINEAR_GAIN = 1.7
ANGULAR_GAIN = 2.3


# ============================================================
# 3. BALL APPROACH AND KICKING
# ============================================================

# Enter kicking state when close enough to control the ball
KICK_ENTER_M = 1.2

# Hysteresis prevents repeated entering/exiting
KICK_EXIT_M = 1.6

# Approach from behind the ball
CHASE_BEHIND_M = 0.25


# ============================================================
# 4. DEFENDING AND SUPPORT
# ============================================================

GUARD_FACE_BALL = True

# React earlier to attacking threats
GUARD_THREAT_ENTER_X = -0.7
GUARD_THREAT_EXIT_X = -0.4

# Keep support players close enough for combination play
SUPPORT_DIST_M = 2.2


# ============================================================
# 5. TEAM COORDINATION
# ============================================================

# Prevent unnecessary switching between attackers
ATTACKER_KEEP_DIST_MARGIN_M = 0.45

# Fallen robots should not be selected unnecessarily
FALLEN_COST = 10.0

# Prevent the defender role from flipping between two players
DEFENDER_KEEP_DIST_MARGIN_M = 0.5

# Ball must be this far from the centre line before the support
# player changes sides (prevents left/right flicker near y = 0)
SUPPORT_SIDE_DEADBAND_M = 0.3


# ============================================================
# 6. KICKOFF AND SET PLAYS
# ============================================================

KICKOFF_STAGE_M = 2.0
KICKOFF_FRONT_MARGIN = 0.1
KICKOFF_LATERAL_TOL = 0.35

CENTER_LEAVE_DIST_M = 0.15

OPP_SET_WALL_DIST_M = 2.0

OPP_SET_PLAY_CLEARANCE_M = 1.5
OPP_SET_PLAY_FIELD_MARGIN_M = 0.3


# ============================================================
# 7. POSITIONING AND AVOIDANCE
# ============================================================

OPPONENT_RESTART_AVOID_M = 1.65
CIRCLE_MARGIN_M = 0.3


# ============================================================
# 8. SHOOTING GEOMETRY
# ============================================================

# Aim slightly inside the goal
GOAL_TARGET_DEPTH_M = 0.25

# Open shooting lanes are all treated as equally open beyond this
# clearance, so the centre-of-goal bonus can break the tie
SHOT_CLEARANCE_CAP_M = 1.5


# ============================================================
# 9. OBSTACLE GEOMETRY
# ============================================================

BALL_OBSTACLE_RADIUS = 0.5

OPPONENT_RADIUS = 0.55
TEAMMATE_RADIUS = 0.48

# Maintain safe separation
SAFETY_MARGIN = 0.22

GOAL_DEPTH = 0.6
POST_RADIUS = 0.18
NET_RADIUS = 0.20
NET_STEP = 0.35

START_IGNORE = 0.0
TARGET_IGNORE = 0.0


# ============================================================
# 10. GLOBAL PATH PLANNER
# ============================================================

USE_GLOBAL_PATH_PLANNER = True

# More detailed navigation
GLOBAL_GRID_RESOLUTION_M = 0.25

GLOBAL_FIELD_MARGIN_M = 0.25
GLOBAL_OBSTACLE_MARGIN_M = 0.12

# Avoid looking too far ahead during close ball control
GLOBAL_PATH_LOOKAHEAD_M = 0.8


# ============================================================
# 11. LOCAL PATH PLANNER (VFH)
# ============================================================

PLAN_LOOKAHEAD = 1.0

PLAN_CLEARANCE = 0.4

# Finer directional scanning
PLAN_STEP = math.radians(10)

PLAN_MAX_OFFSET = math.radians(110)


# ============================================================
# 12. VISUALIZATION
# ============================================================

KICK_TARGET_MARK_SIZE_M = 0.18

