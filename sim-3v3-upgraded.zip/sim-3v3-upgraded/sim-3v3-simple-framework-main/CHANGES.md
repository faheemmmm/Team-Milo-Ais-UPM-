# Strategy upgrades (untested in Booster Studio sim - verify before competing)

- utils/aim.py (new): shot placement picks the goal gap farthest from opponents; open-field kicks
  pick the safest forward direction (never backward, never into the touch line). Aim is locked
  briefly (AIM_LOCK_SEC) to avoid jitter.
- player.py: plan_kick uses aim; goalie shadows ball y and steps out; support = forward slot when
  ball.x > FORWARD_BALL_X else blocking slot; walk_to(ball_clear=...) for restart clearance.
- main.py: sticky goalie role; set plays (corner cross, indirect-FK lay-off, penalty positions);
  opponent restarts retreat past 3 m (legal + avoids the no-activity penalty).
- param.py: all new constants documented. Tune KICK_POWER_* first in the sim.
